#initialize host and port sa constructor
#initialize socket as attrib
#create socket sa run
import pickle
import socket
class Server():
	BUFFER_SIZE = 4096
	socket = None
	hostname = ''
	port = ''

	def __init__(self, hostname, port):
		self.hostname = hostname
		self.port = port

	def run(self):
		self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		server_addr = (self.hostname, self.port)
		self.socket.bind(server_addr)
		
		print("Hosting at: ", self.hostname)

		while True:
			data, addr = self.socket.recvfrom(self.BUFFER_SIZE)
			loaded_data = pickle.loads(data)
			packet_type = loaded_data.packet_type

			if packet_type == "CONNECT":
				print("{} succesfully connected to server!".format(loaded_data.player.name))

