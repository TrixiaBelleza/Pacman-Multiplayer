import server

port = 10939
server = server.Server('0.0.0.0',port)
server.run()
