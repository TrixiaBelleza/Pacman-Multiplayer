import client

name = input("Enter your name: ")
ptype = input("Enter your type: ")

c = client.Client(name, ptype)

hostname = '127.0.0.1'
port = 10950

c.hostname = hostname
c.port = port

c.connect()
